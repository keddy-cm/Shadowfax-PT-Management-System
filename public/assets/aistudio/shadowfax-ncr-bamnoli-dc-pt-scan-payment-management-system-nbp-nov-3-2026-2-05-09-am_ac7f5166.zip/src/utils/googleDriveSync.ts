/**
 * Google Drive Backup & Sync Utility for Shadowfax NCR Bamnoli DC (NBP)
 * Provides direct Google Drive file synchronization, Apps Script Drive Relay,
 * and structured Drive export workflows.
 */

import * as XLSX from 'xlsx';
import { AppDatabase, RateConfig, DriveSyncLog } from '../types';
import { generateDailyExcelReport, exportWorkbook } from './excelExport';
import { logDriveSync } from '../db/storage';

export const TARGET_DRIVE_FOLDER_ID = '1awbpzVsqjcuNil31zNEuxhC40-vZoodU';
export const TARGET_DRIVE_FOLDER_URL = 'https://drive.google.com/drive/folders/1awbpzVsqjcuNil31zNEuxhC40-vZoodU';

export interface DriveSyncResult {
  success: boolean;
  message: string;
  folderUrl?: string;
  excelFileUrl?: string;
  jsonFileUrl?: string;
}

/**
 * Builds the payload for Google Drive upload
 */
export function buildDriveUploadPayload(
  db: AppDatabase,
  operationalDate: string,
  rateConfig?: RateConfig
) {
  const wb = generateDailyExcelReport(db, operationalDate);
  const excelBase64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
  const excelFileName = `NBP_DC_PT_Daily_Report_${operationalDate}.xlsx`;
  const jsonFileName = `NBP_DC_Database_Snapshot_${operationalDate}.json`;
  const jsonContent = JSON.stringify(db, null, 2);

  return {
    operationalDate,
    excelFileName,
    excelBase64,
    jsonFileName,
    jsonContent,
  };
}

/**
 * Uploads report directly to Google Drive via Google Apps Script Webhook
 * (Runs natively inside Shadowfax Google Workspace without needing GCP project creation)
 */
export async function uploadToDriveViaWebhook(
  webhookUrl: string,
  db: AppDatabase,
  operationalDate: string,
  rateConfig?: RateConfig
): Promise<DriveSyncResult> {
  try {
    const payload = buildDriveUploadPayload(db, operationalDate, rateConfig);

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errTxt = await response.text();
      return {
        success: false,
        message: `Drive Webhook returned HTTP ${response.status}: ${errTxt.slice(0, 100)}`,
      };
    }

    const data = await response.json();
    if (data.status === 'success') {
      // Log sync
      logDriveSync({
        id: 'drive-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
        synced_at: new Date().toISOString(),
        operational_date: operationalDate,
        file_name: payload.excelFileName,
        folder_name: `Designated Folder (${TARGET_DRIVE_FOLDER_ID}) / ${operationalDate}`,
        drive_url: data.folderUrl || TARGET_DRIVE_FOLDER_URL,
        status: 'SUCCESS',
        total_records: db.scanRateRecords.filter((r) => r.operational_date === operationalDate).length,
        total_payment: 0,
      });

      return {
        success: true,
        message: 'Daily report and database snapshot successfully saved to designated Google Drive folder!',
        folderUrl: data.folderUrl || TARGET_DRIVE_FOLDER_URL,
        excelFileUrl: data.excelUrl,
        jsonFileUrl: data.jsonUrl,
      };
    } else {
      return {
        success: false,
        message: data.message || 'Google Drive webhook reported an error.',
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: `Failed to upload to Google Drive: ${err.message || String(err)}`,
    };
  }
}

/**
 * Uploads directly via Google Drive v3 REST API when access token is provided
 */
export async function uploadToDriveViaApi(
  accessToken: string,
  db: AppDatabase,
  operationalDate: string,
  folderId?: string
): Promise<DriveSyncResult> {
  try {
    const targetFolder = folderId || TARGET_DRIVE_FOLDER_ID;
    const payload = buildDriveUploadPayload(db, operationalDate);

    // 1. Upload Excel File
    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const metadata = {
      name: payload.excelFileName,
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      parents: targetFolder ? [targetFolder] : undefined,
    };

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n' +
      'Content-Transfer-Encoding: base64\r\n\r\n' +
      payload.excelBase64 +
      closeDelimiter;

    const response = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: multipartRequestBody,
      }
    );

    if (response.ok) {
      const result = await response.json();
      const driveUrl = `https://drive.google.com/file/d/${result.id}/view`;

      logDriveSync({
        id: 'drive-' + Date.now(),
        synced_at: new Date().toISOString(),
        operational_date: operationalDate,
        file_name: payload.excelFileName,
        folder_name: `Designated Folder (${targetFolder})`,
        drive_file_id: result.id,
        drive_url: driveUrl,
        status: 'SUCCESS',
        total_records: db.scanRateRecords.filter((r) => r.operational_date === operationalDate).length,
        total_payment: 0,
      });

      return {
        success: true,
        message: 'Successfully uploaded daily report directly to designated Google Drive folder!',
        excelFileUrl: driveUrl,
      };
    } else {
      const errTxt = await response.text();
      return {
        success: false,
        message: `Google Drive API error: ${errTxt.slice(0, 150)}`,
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: `Direct Drive API upload failed: ${err.message || String(err)}`,
    };
  }
}

/**
 * Triggers downloading the complete daily package for Google Drive upload
 */
export function exportPackageForGoogleDrive(
  db: AppDatabase,
  operationalDate: string,
  rateConfig?: RateConfig
): void {
  // 1. Download the formatted Excel report
  const wb = generateDailyExcelReport(db, operationalDate);
  exportWorkbook(wb, `NBP_DC_PT_Daily_Report_${operationalDate}.xlsx`);

  // 2. Download the JSON DB snapshot
  setTimeout(() => {
    const jsonBlob = new Blob([JSON.stringify(db, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(jsonBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NBP_DC_Database_Snapshot_${operationalDate}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 400);

  // Log download
  logDriveSync({
    id: 'drive-dl-' + Date.now(),
    synced_at: new Date().toISOString(),
    operational_date: operationalDate,
    file_name: `NBP_DC_PT_Daily_Report_${operationalDate}.xlsx`,
    folder_name: `Designated Folder (${TARGET_DRIVE_FOLDER_ID}) / ${operationalDate}`,
    drive_url: TARGET_DRIVE_FOLDER_URL,
    status: 'DOWNLOADED',
    total_records: db.scanRateRecords.filter((r) => r.operational_date === operationalDate).length,
    total_payment: 0,
  });
}

/**
 * Opens Google Drive in a new tab to user's Drive folder for direct file drop
 */
export function openGoogleDriveWeb(customFolderUrl?: string): void {
  window.open(customFolderUrl || TARGET_DRIVE_FOLDER_URL, '_blank');
}

/**
 * Ready-to-use Google Apps Script Drive Relay for Shadowfax Google Workspace
 * Pre-configured with designated folder: 1awbpzVsqjcuNil31zNEuxhC40-vZoodU
 */
export const GOOGLE_DRIVE_APPS_SCRIPT_TEMPLATE = `
/**
 * Shadowfax NBP DC — Google Drive Automated Sync Relay
 * Pre-configured for designated folder: https://drive.google.com/drive/folders/1awbpzVsqjcuNil31zNEuxhC40-vZoodU
 * 
 * 1. Open https://script.google.com
 * 2. Create new project and paste this code
 * 3. Click "Deploy" > "New deployment" > Select type: "Web app"
 * 4. Execute as: "Me" | Who has access: "Anyone"
 * 5. Copy the Web app URL and paste it into Google Drive Settings!
 */
function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var designatedFolderId = "1awbpzVsqjcuNil31zNEuxhC40-vZoodU";
    var mainFolder;
    
    // Connect directly to the designated Google Drive folder
    try {
      mainFolder = DriveApp.getFolderById(designatedFolderId);
    } catch (folderErr) {
      var rootFolder = DriveApp.getRootFolder();
      var mainFolders = rootFolder.getFoldersByName("Shadowfax NBP DC Reports");
      mainFolder = mainFolders.hasNext() ? mainFolders.next() : rootFolder.createFolder("Shadowfax NBP DC Reports");
    }
    
    // Find or create subfolder for operational date inside designated folder
    var dateFolders = mainFolder.getFoldersByName(data.operationalDate);
    var dateFolder = dateFolders.hasNext() ? dateFolders.next() : mainFolder.createFolder(data.operationalDate);
    
    // Save Excel Report
    var excelBlob = Utilities.newBlob(
      Utilities.base64Decode(data.excelBase64),
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      data.excelFileName
    );
    var excelFile = dateFolder.createFile(excelBlob);
    excelFile.setDescription('Shadowfax NCR Bamnoli DC PT Scan & Payout Report for ' + data.operationalDate);
    
    // Save JSON DB Snapshot
    var jsonBlob = Utilities.newBlob(data.jsonContent, 'application/json', data.jsonFileName);
    var jsonFile = dateFolder.createFile(jsonBlob);
    
    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      folderUrl: dateFolder.getUrl(),
      excelUrl: excelFile.getUrl(),
      jsonUrl: jsonFile.getUrl()
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
`.trim();
