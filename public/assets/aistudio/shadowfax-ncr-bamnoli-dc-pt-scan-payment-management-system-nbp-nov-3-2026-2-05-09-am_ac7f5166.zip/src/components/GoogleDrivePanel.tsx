import React, { useState } from 'react';
import { AppDatabase, RateConfig, DriveConfig, DriveSyncLog } from '../types';
import {
  exportPackageForGoogleDrive,
  openGoogleDriveWeb,
  uploadToDriveViaWebhook,
  uploadToDriveViaApi,
  GOOGLE_DRIVE_APPS_SCRIPT_TEMPLATE,
  buildDriveUploadPayload,
  TARGET_DRIVE_FOLDER_ID,
  TARGET_DRIVE_FOLDER_URL,
} from '../utils/googleDriveSync';
import { updateDriveConfig, clearDriveLogs } from '../db/storage';
import {
  Cloud,
  FolderSync,
  UploadCloud,
  ExternalLink,
  Settings2,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  FileArchive,
  Copy,
  Check,
  RefreshCw,
  Info,
  ShieldCheck,
  FolderOpen,
  Trash2,
  ArrowLeft,
  X,
} from 'lucide-react';

interface GoogleDrivePanelProps {
  db: AppDatabase;
  operationalDate: string;
  currentRate: RateConfig;
  onRefresh: () => void;
  onClose?: () => void;
}

export const GoogleDrivePanel: React.FC<GoogleDrivePanelProps> = ({
  db,
  operationalDate,
  currentRate,
  onRefresh,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'sync' | 'history' | 'settings'>('sync');
  const [isSyncing, setIsSyncing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [directToken, setDirectToken] = useState('');

  const driveConfig: DriveConfig = db.driveConfig || {
    isEnabled: true,
    driveFolderId: TARGET_DRIVE_FOLDER_ID,
    driveFolderUrl: TARGET_DRIVE_FOLDER_URL,
    autoSyncDaily: true,
    totalSyncedFiles: 0,
  };

  const driveLogs = db.driveLogs || [];

  const handleSyncNow = async () => {
    setIsSyncing(true);
    setStatusMessage('Generating multi-sheet Excel audit workbook & database snapshot...');
    setErrorMessage(null);

    try {
      if (driveConfig.webhookUrl) {
        // Use Google Apps Script Webhook
        setStatusMessage('Uploading files to Shadowfax Google Drive via Webhook...');
        const res = await uploadToDriveViaWebhook(driveConfig.webhookUrl, db, operationalDate, currentRate);
        if (res.success) {
          setStatusMessage(res.message);
          onRefresh();
        } else {
          setErrorMessage(res.message);
        }
      } else if (directToken.trim()) {
        // Use Direct REST API with Bearer token
        setStatusMessage('Uploading files directly to Google Drive via Drive v3 API...');
        const res = await uploadToDriveViaApi(directToken.trim(), db, operationalDate);
        if (res.success) {
          setStatusMessage(res.message);
          onRefresh();
        } else {
          setErrorMessage(res.message);
        }
      } else {
        // Fallback: Export package directly and open Google Drive Web
        setStatusMessage('Exporting Drive-formatted package and opening Google Drive in new tab...');
        exportPackageForGoogleDrive(db, operationalDate, currentRate);
        openGoogleDriveWeb(driveConfig.driveFolderUrl);
        setStatusMessage('Excel report and DB snapshot downloaded! Please drag & drop them into your Google Drive tab.');
        onRefresh();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to sync with Google Drive');
    } finally {
      setIsSyncing(false);
      setTimeout(() => setStatusMessage(null), 8000);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GOOGLE_DRIVE_APPS_SCRIPT_TEMPLATE);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const handleUpdateConfig = (changes: Partial<DriveConfig>) => {
    updateDriveConfig(changes);
    onRefresh();
  };

  return (
    <div className="space-y-4">
      {/* Top Navigation Back Row */}
      {onClose && (
        <div className="flex items-center justify-between bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-2xs">
          <button
            onClick={onClose}
            className="flex items-center gap-2 text-xs font-bold text-slate-800 hover:text-sky-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-sky-600" />
            <span>← Back to Dashboard Overview</span>
          </button>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 border border-slate-200 rounded-lg text-xs font-semibold text-slate-600 transition-colors"
            title="Close Google Drive Panel"
          >
            <X className="w-3.5 h-3.5" />
            <span>Close Panel</span>
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-400 shadow-inner">
              <Cloud className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight text-white">
                  Google Drive Storage & Archival Sync
                </h2>
                <span className="bg-sky-500/20 text-sky-400 border border-sky-500/40 text-xs px-2.5 py-0.5 rounded-full font-mono font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
                  DRIVE READY
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                Automatically saves daily DC audit spreadsheets (<code className="font-mono text-sky-300">.xlsx</code>)
                and immutable database snapshots into your Shadowfax Google Drive folder for compliance and team access.
              </p>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex flex-wrap items-center gap-2">
            {onClose && (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-600 rounded-xl text-xs font-bold transition-colors shadow-xs"
                title="Return to Dashboard"
              >
                <ArrowLeft className="w-4 h-4 text-sky-400" />
                <span>Back to Dashboard</span>
              </button>
            )}
            <button
              onClick={() => openGoogleDriveWeb(driveConfig.driveFolderUrl)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-xl text-xs font-semibold text-slate-200 transition-colors shadow-xs"
            >
              <FolderOpen className="w-4 h-4 text-amber-400" />
              <span>Open Google Drive</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </button>

            <button
              onClick={handleSyncNow}
              disabled={isSyncing}
              className="flex items-center gap-2 px-5 py-2 bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              {isSyncing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                  <span>Syncing to Drive...</span>
                </>
              ) : (
                <>
                  <UploadCloud className="w-4 h-4 text-slate-950" />
                  <span>Sync Today's Data to Drive</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Status Bar */}
        <div className="mt-5 pt-4 border-t border-slate-700/80 flex flex-wrap items-center justify-between text-xs text-slate-300 gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5 text-sky-300 font-medium">
              <FolderSync className="w-4 h-4" />
              Target Folder:
              <a
                href={driveConfig.driveFolderUrl || TARGET_DRIVE_FOLDER_URL}
                target="_blank"
                rel="noreferrer"
                className="font-mono text-white bg-sky-950/90 hover:bg-sky-900 px-2 py-0.5 rounded border border-sky-500/50 flex items-center gap-1 transition-colors underline"
                title="Open designated Google Drive folder in new tab"
              >
                <span>{driveConfig.driveFolderId || TARGET_DRIVE_FOLDER_ID}</span>
                <ExternalLink className="w-3 h-3 text-sky-300" />
              </a>
              <span className="text-slate-400">/ {operationalDate}</span>
            </span>
            <span>•</span>
            <span>Operational Date: <strong className="text-white font-mono">{operationalDate}</strong></span>
          </div>

          <div className="text-slate-400 font-mono text-[11px]">
            Total Drive Syncs: {driveConfig.totalSyncedFiles || driveLogs.length}
          </div>
        </div>
      </div>

      {/* Corporate GCP Policy Explanatory Card */}
      <div className="bg-sky-50/70 border border-sky-200/90 rounded-xl p-4 text-xs text-sky-950 flex flex-col sm:flex-row items-start gap-3">
        <Info className="w-5 h-5 text-sky-700 shrink-0 mt-0.5" />
        <div className="space-y-1 text-slate-700">
          <p className="font-bold text-sky-900">
            Why Google Drive Project Creation Failed & How It Works Here:
          </p>
          <p className="leading-relaxed">
            Corporate accounts (<span className="font-mono text-sky-900 font-semibold">@shadowfax.in</span>) have security policies preventing direct external Google Cloud Project creation (which caused the <span className="italic font-medium">"Failed to create project"</span> error).
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 pt-2 border-t border-sky-200/80 font-medium text-slate-800">
            <div>
              <strong>1. Instant Upload:</strong> Clicking <span className="font-bold text-sky-900">"Sync Today's Data to Drive"</span> packages the complete multi-sheet Excel file and opens your Drive folder ready to receive it.
            </div>
            <div>
              <strong>2. Headless Auto-Upload:</strong> Paste the 1-minute Google Apps Script Webhook in the Settings tab to automatically save files straight to Google Drive in the background!
            </div>
          </div>
        </div>
      </div>

      {/* Success Banner */}
      {statusMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between gap-3 text-emerald-900 text-xs font-semibold shadow-xs animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700 hover:text-emerald-900 text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-300 rounded-xl flex items-center justify-between gap-3 text-rose-900 text-xs font-semibold shadow-xs animate-fade-in">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-700 hover:text-rose-900 text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* Sub-Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('sync')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'sync'
              ? 'border-sky-500 text-sky-700 bg-sky-50/50'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <UploadCloud className="w-4 h-4" />
          <span>Drive Backup & Export</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'history'
              ? 'border-sky-500 text-sky-700 bg-sky-50/50'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Sync History ({driveLogs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'settings'
              ? 'border-sky-500 text-sky-700 bg-sky-50/50'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Settings2 className="w-4 h-4" />
          <span>Drive Connection Settings</span>
        </button>
      </div>

      {/* TAB 1: Backup & Export */}
      {activeTab === 'sync' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            {/* Sync Mode Status Banner */}
            {!driveConfig.webhookUrl && !directToken.trim() ? (
              <div className="p-4 bg-amber-50/90 border border-amber-300 rounded-xl space-y-2.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-amber-900 text-xs">
                        Drive Auto-Upload Not Active Yet (Assisted Manual Drop Mode)
                      </h4>
                      <p className="text-[11px] text-amber-800 leading-relaxed mt-0.5">
                        Clicking sync currently downloads the files to your device and opens your designated folder (<code className="bg-amber-100/80 font-mono font-bold px-1 rounded">{driveConfig.driveFolderId}</code>) so you can drag & drop them in.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('settings')}
                    className="px-3.5 py-1.5 bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs rounded-lg shrink-0 transition-colors shadow-xs"
                  >
                    Enable 1-Min Auto-Upload
                  </button>
                </div>
                <div className="text-[11px] text-amber-900 bg-amber-100/80 p-2.5 rounded-lg border border-amber-200 leading-relaxed">
                  📢 <strong>Will files upload automatically when published?</strong> No. Publishing the web app makes the URL public, but Google Drive requires explicit write authorization from your <code className="font-mono font-semibold">@shadowfax.in</code> account to create files in folder <code className="font-mono font-semibold">{driveConfig.driveFolderId}</code>. Connecting the 1-minute Google Apps Script Webhook below enables 100% automatic direct upload.
                </div>
              </div>
            ) : (
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between text-xs text-emerald-900">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-bold">
                    100% Automated Background Drive Sync is Active!
                  </span>
                </div>
                <span className="font-mono text-[11px] text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded border border-emerald-200">
                  Target: {driveConfig.driveFolderId}
                </span>
              </div>
            )}

            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                Files Prepared for Google Drive Upload ({operationalDate})
              </h3>

              <div className="space-y-3 text-xs">
                {/* File Item 1: Excel */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 font-bold">
                      XLS
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 font-mono">
                        NBP_DC_PT_Daily_Report_{operationalDate}.xlsx
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Multi-tab audit report (Dashboard, PT Details, Hourly scans, Block breakdown)
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500 bg-white px-2 py-1 rounded border border-slate-200">
                    ~45 KB
                  </span>
                </div>

                {/* File Item 2: JSON Snapshot */}
                <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-sky-100 border border-sky-300 flex items-center justify-center text-sky-700 font-bold">
                      JSON
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 font-mono">
                        NBP_DC_Database_Snapshot_{operationalDate}.json
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Complete raw scan database, roster mappings, rates, and audit logs
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-slate-500 bg-white px-2 py-1 rounded border border-slate-200">
                    ~25 KB
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-slate-200 flex flex-wrap gap-2">
                <button
                  onClick={handleSyncNow}
                  disabled={isSyncing}
                  className="flex items-center gap-2 px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs shadow-xs transition-colors"
                >
                  <UploadCloud className="w-4 h-4 text-slate-950" />
                  <span>Sync Both Files to Google Drive</span>
                </button>

                <button
                  onClick={() => exportPackageForGoogleDrive(db, operationalDate, currentRate)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-xs font-semibold text-slate-700 transition-colors"
                >
                  <FileArchive className="w-4 h-4 text-slate-600" />
                  <span>Download Package Locally</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Guide Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4 h-fit">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-600" />
              Google Drive Organization
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Files are automatically categorized into a dedicated hierarchical folder structure inside your Shadowfax Google Drive:
            </p>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs font-mono text-slate-700 space-y-1.5">
              <div className="font-bold text-sky-900">📁 Google Drive (Designated Folder)</div>
              <div className="pl-3 text-sky-800 font-semibold">↳ 📂 Folder: 1awbpzVsqjcuNil31zNEuxhC40-vZoodU</div>
              <div className="pl-6 text-amber-700">↳ 📁 {operationalDate}</div>
              <div className="pl-9 text-slate-600">↳ 📄 NBP_DC_PT_Daily_Report_{operationalDate}.xlsx</div>
              <div className="pl-9 text-slate-600">↳ 📄 NBP_DC_Database_Snapshot_{operationalDate}.json</div>
            </div>
            <button
              onClick={() => openGoogleDriveWeb(driveConfig.driveFolderUrl || TARGET_DRIVE_FOLDER_URL)}
              className="w-full flex items-center justify-center gap-1.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold transition-colors"
            >
              <span>Open in Google Drive Web</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: History */}
      {activeTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Google Drive Synchronization Log</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Audit trail of reports saved to Google Drive
              </p>
            </div>
            {driveLogs.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('Clear Drive sync logs?')) {
                    clearDriveLogs();
                    onRefresh();
                  }
                }}
                className="text-xs text-rose-600 hover:text-rose-700 font-medium"
              >
                Clear History
              </button>
            )}
          </div>

          {driveLogs.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Date & Time</th>
                    <th className="py-2 px-3">Operational Date</th>
                    <th className="py-2 px-3">File Name</th>
                    <th className="py-2 px-3">Target Folder</th>
                    <th className="py-2 px-3">Status</th>
                    <th className="py-2 px-3">Link</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {driveLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-slate-600">
                        {new Date(log.synced_at).toLocaleString('en-IN', {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-2.5 px-3 text-slate-900 font-bold">{log.operational_date}</td>
                      <td className="py-2.5 px-3 font-sans text-slate-800">{log.file_name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{log.folder_name}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded ${
                            log.status === 'SUCCESS'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-300'
                              : 'bg-sky-50 text-sky-700 border border-sky-300'
                          }`}
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          {log.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        {log.drive_url ? (
                          <a
                            href={log.drive_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-sky-600 hover:text-sky-800 underline flex items-center gap-1 font-sans font-semibold"
                          >
                            <span>Open Drive</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        ) : (
                          <span className="text-slate-400 font-sans">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-10 text-slate-400 text-xs">
              <Cloud className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <p>No Google Drive sync records yet. Click "Sync Today's Data to Drive" above.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Settings */}
      {activeTab === 'settings' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs max-w-3xl space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">Google Drive Configuration</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Choose automated background sync via Google Apps Script or direct folder link
            </p>
          </div>

          <div className="space-y-4 text-xs">
            {/* Preferred Target Folder URL */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <label className="block font-bold text-slate-800">
                  Target Google Drive Folder URL:
                </label>
                <button
                  type="button"
                  onClick={() =>
                    handleUpdateConfig({
                      driveFolderUrl: TARGET_DRIVE_FOLDER_URL,
                      driveFolderId: TARGET_DRIVE_FOLDER_ID,
                    })
                  }
                  className="text-[11px] font-bold text-sky-700 hover:text-sky-900 hover:underline"
                >
                  Reset to Assigned Folder
                </button>
              </div>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder={TARGET_DRIVE_FOLDER_URL}
                  value={driveConfig.driveFolderUrl || TARGET_DRIVE_FOLDER_URL}
                  onChange={(e) =>
                    handleUpdateConfig({
                      driveFolderUrl: e.target.value.trim(),
                      driveFolderId:
                        e.target.value.trim().match(/folders\/([a-zA-Z0-9_-]+)/)?.[1] ||
                        TARGET_DRIVE_FOLDER_ID,
                    })
                  }
                  className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
                />
                <a
                  href={driveConfig.driveFolderUrl || TARGET_DRIVE_FOLDER_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shrink-0"
                >
                  <span>Open Folder</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <p className="text-slate-500 text-[11px]">
                Target Folder ID: <code className="font-mono text-slate-800 bg-slate-200/80 px-1.5 py-0.5 rounded font-semibold">{driveConfig.driveFolderId || TARGET_DRIVE_FOLDER_ID}</code>. Operational spreadsheets, roster payment records, and database snapshots are stored here.
              </p>
            </div>

            {/* Google Apps Script Drive Relay (Recommended) */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">
                      Google Apps Script Drive Auto-Sync Webhook
                    </span>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded">
                      Zero GCP Project Required
                    </span>
                  </div>
                  <p className="text-slate-500 mt-0.5">
                    Enables 100% headless, background file creation directly inside your Shadowfax Google Drive.
                  </p>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Apps Script Web App URL:
                </label>
                <input
                  type="url"
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  value={driveConfig.webhookUrl || ''}
                  onChange={(e) => handleUpdateConfig({ webhookUrl: e.target.value.trim() })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700">Setup Instructions:</span>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-white border border-slate-300 hover:bg-slate-100 rounded text-slate-800 font-bold text-[11px] shadow-2xs"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-600" />}
                    <span>{copiedCode ? 'Code Copied!' : 'Copy Drive Script'}</span>
                  </button>
                </div>
                <ol className="list-decimal list-inside text-slate-600 space-y-1 text-[11px] leading-relaxed">
                  <li>Open <a href="https://script.google.com" target="_blank" rel="noreferrer" className="text-sky-600 underline font-semibold">script.google.com</a> in your browser.</li>
                  <li>Click <strong>"New project"</strong>, paste the copied Drive script, and click save.</li>
                  <li>Click <strong>Deploy &gt; New deployment</strong>, choose type <strong>"Web app"</strong>.</li>
                  <li>Set <em>Execute as:</em> <strong>Me</strong> and <em>Who has access:</em> <strong>Anyone</strong>.</li>
                  <li>Deploy and paste the resulting URL above!</li>
                </ol>
              </div>
            </div>

            {/* Direct Token Option */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <label className="block font-bold text-slate-800">
                Direct OAuth 2.0 Bearer Token (Optional / Advanced):
              </label>
              <input
                type="password"
                placeholder="ya29.a0AfH6SM..."
                value={directToken}
                onChange={(e) => setDirectToken(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
              />
              <p className="text-slate-500 text-[11px]">
                If your enterprise provides a temporary OAuth access token, you can paste it here to upload via Google Drive REST API.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
