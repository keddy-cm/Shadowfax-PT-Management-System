import React, { useState, useEffect, useCallback } from 'react';
import {
  loadDatabase,
  getActiveRateForDate,
} from './db/storage';
import { AppDatabase, RateConfig } from './types';
import { Header, NavTab } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { PtDetailsAndCalculator } from './components/PtDetailsAndCalculator';
import { UploadScanRateModal } from './components/UploadScanRateModal';
import { UploadScanHistoryModal } from './components/UploadScanHistoryModal';
import { AdminPanel } from './components/AdminPanel';
import { ReportsHub } from './components/ReportsHub';
import { MailBotPanel } from './components/MailBotPanel';
import { GoogleDrivePanel } from './components/GoogleDrivePanel';
import { ChatAssistant } from './components/ChatAssistant';
import { PtPortalPage } from './components/PtPortalPage';
import { AdminAuthModal } from './components/AdminAuthModal';
import { SharePtPortalModal } from './components/SharePtPortalModal';
import { ADMIN_AUTH_STORAGE_KEY } from './utils/auth';
import { CheckCircle, AlertTriangle, X } from 'lucide-react';

/**
 * Checks if current browser URL corresponds to the standalone PT worker portal
 */
function isPtPortalRoute(): boolean {
  if (typeof window === 'undefined') return false;
  const urlParams = new URLSearchParams(window.location.search);
  return (
    urlParams.get('portal') === 'pt' ||
    urlParams.get('page') === 'pt' ||
    window.location.hash === '#pt' ||
    window.location.hash === '#pt-portal' ||
    window.location.pathname === '/pt' ||
    window.location.pathname === '/pt-portal'
  );
}

export default function App() {
  // Check if loaded in isolated PT Portal mode
  const [isPtPortal, setIsPtPortal] = useState<boolean>(() => isPtPortalRoute());

  const [operationalDate, setOperationalDate] = useState<string>(() => {
    const now = new Date();
    return now.toISOString().split('T')[0];
  });

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem(ADMIN_AUTH_STORAGE_KEY) === 'true';
    }
    return false;
  });
  const [showAdminAuthModal, setShowAdminAuthModal] = useState<boolean>(false);
  const [showSharePtModal, setShowSharePtModal] = useState<boolean>(false);

  const [userRole, setUserRole] = useState<'ADMIN' | 'MANAGER'>(() => {
    if (typeof window !== 'undefined' && sessionStorage.getItem(ADMIN_AUTH_STORAGE_KEY) === 'true') {
      return 'ADMIN';
    }
    return 'MANAGER';
  });
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string>(() =>
    new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );

  const [selectedPtId, setSelectedPtId] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'info' | 'warning'; message: string } | null>(null);
  const [db, setDb] = useState<AppDatabase>(() => loadDatabase());

  const currentRate: RateConfig = getActiveRateForDate(operationalDate);

  // Listen to popstate and hashchange to detect URL switches
  useEffect(() => {
    const handleUrlChange = () => {
      setIsPtPortal(isPtPortalRoute());
    };
    window.addEventListener('popstate', handleUrlChange);
    window.addEventListener('hashchange', handleUrlChange);
    return () => {
      window.removeEventListener('popstate', handleUrlChange);
      window.removeEventListener('hashchange', handleUrlChange);
    };
  }, []);

  const reloadData = useCallback(() => {
    setIsRefreshing(true);
    const freshDb = loadDatabase();
    setDb({ ...freshDb });
    setLastRefreshedAt(
      new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    );
    setTimeout(() => {
      setIsRefreshing(false);
    }, 400);
  }, []);

  useEffect(() => {
    if (!autoRefresh || isPtPortal) return;
    const interval = setInterval(() => {
      reloadData();
    }, 30000);
    return () => clearInterval(interval);
  }, [autoRefresh, isPtPortal, reloadData]);

  const handleAdminAuthSuccess = () => {
    setIsAdminAuthenticated(true);
    setUserRole('ADMIN');
    setShowAdminAuthModal(false);
    setActiveTab('admin');
    showToast('Admin access unlocked successfully. Logged in as Admin.', 'success');
  };

  const handleLockAdmin = () => {
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem(ADMIN_AUTH_STORAGE_KEY);
    }
    setIsAdminAuthenticated(false);
    setUserRole('MANAGER');
    if (activeTab === 'admin') {
      setActiveTab('dashboard');
    }
    showToast('Admin session locked. Credentials (ID: Admin / Sfx@123) required.', 'info');
  };

  const handleViewPtDetails = (scanId: string) => {
    setSelectedPtId(scanId);
    setActiveTab('pt-details');
  };

  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  // =========================================================================
  // 1. STANDALONE PT PORTAL VIEW
  // Strict isolation: Zero access to DC dashboard, no header, no chat bot, no metrics
  // =========================================================================
  if (isPtPortal) {
    return (
      <PtPortalPage
        db={db}
        operationalDate={operationalDate}
        currentRate={currentRate}
      />
    );
  }

  // =========================================================================
  // 2. MAIN DC OPERATIONS DASHBOARD (SUPERVISORS / MANAGERS / ADMINS)
  // =========================================================================
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        operationalDate={operationalDate}
        setOperationalDate={setOperationalDate}
        userRole={userRole}
        setUserRole={setUserRole}
        autoRefresh={autoRefresh}
        setAutoRefresh={setAutoRefresh}
        onManualRefresh={reloadData}
        isRefreshing={isRefreshing}
        lastRefreshedAt={lastRefreshedAt}
        isAdminAuthenticated={isAdminAuthenticated}
        onRequireAdminAuth={() => setShowAdminAuthModal(true)}
        onLockAdmin={handleLockAdmin}
        onOpenSharePtModal={() => setShowSharePtModal(true)}
      />

      {/* Global Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md animate-fade-in">
          <div
            className={`p-4 rounded-xl shadow-lg border flex items-start gap-3 ${
              notification.type === 'success'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                : notification.type === 'warning'
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white border-slate-300 text-slate-800'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="text-xs flex-1">
              <p className="font-semibold">{notification.message}</p>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-slate-400 hover:text-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            db={db}
            operationalDate={operationalDate}
            currentRate={currentRate}
            onViewPtDetails={handleViewPtDetails}
            onOpenUploadRate={() => setActiveTab('upload-rate')}
            onOpenUploadHistory={() => setActiveTab('upload-history')}
            onOpenMailBot={() => setActiveTab('mailbot')}
            onOpenDrive={() => setActiveTab('drive')}
            onOpenPtPortal={() => setShowSharePtModal(true)}
          />
        )}

        {activeTab === 'pt-details' && (
          <PtDetailsAndCalculator
            db={db}
            operationalDate={operationalDate}
            setOperationalDate={setOperationalDate}
            currentRate={currentRate}
            selectedPtId={selectedPtId}
            onSelectPtId={setSelectedPtId}
            onOpenPtPortal={() => setShowSharePtModal(true)}
          />
        )}

        {activeTab === 'upload-rate' && (
          <UploadScanRateModal
            db={db}
            currentDate={operationalDate}
            onImportComplete={(msg) => {
              reloadData();
              showToast(msg, 'success');
              setActiveTab('dashboard');
            }}
            onCancel={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'upload-history' && (
          <UploadScanHistoryModal
            db={db}
            currentDate={operationalDate}
            onImportComplete={(msg) => {
              reloadData();
              showToast(msg, 'success');
              setActiveTab('dashboard');
            }}
            onCancel={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsHub
            db={db}
            operationalDate={operationalDate}
            setOperationalDate={setOperationalDate}
            currentRate={currentRate}
          />
        )}

        {activeTab === 'mailbot' && (
          <MailBotPanel
            db={db}
            operationalDate={operationalDate}
            currentRate={currentRate}
            onRefresh={reloadData}
            onClose={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'drive' && (
          <GoogleDrivePanel
            db={db}
            operationalDate={operationalDate}
            currentRate={currentRate}
            onRefresh={reloadData}
            onClose={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'admin' && (
          isAdminAuthenticated ? (
            <AdminPanel
              db={db}
              onRefresh={reloadData}
              userRole={userRole}
              operationalDate={operationalDate}
              onLockAdmin={handleLockAdmin}
            />
          ) : (
            <div className="py-16 flex items-center justify-center">
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-lg text-center max-w-md w-full space-y-4 animate-fade-in">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-600">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-900">Admin Authentication Required</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Access to DC PT Roster, Rate configuration, and System management requires administrator sign-in.
                  </p>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 font-mono">
                  Required: ID: <strong>Admin</strong> | Password: <strong>Sfx@123</strong>
                </div>

                <div className="space-y-2 pt-2">
                  <button
                    onClick={() => setShowAdminAuthModal(true)}
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 active:scale-98 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-all"
                  >
                    Enter Admin Credentials (Sfx@123)
                  </button>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors"
                  >
                    Return to Dashboard
                  </button>
                </div>
              </div>
            </div>
          )
        )}
      </main>

      {/* Admin Authentication Modal */}
      <AdminAuthModal
        isOpen={showAdminAuthModal}
        onSuccess={handleAdminAuthSuccess}
        onCancel={() => setShowAdminAuthModal(false)}
      />

      {/* Share PT Portal Link Modal */}
      <SharePtPortalModal
        isOpen={showSharePtModal}
        onClose={() => setShowSharePtModal(false)}
      />

      {/* Floating Operational Chat Assistant */}
      <ChatAssistant
        db={db}
        operationalDate={operationalDate}
        currentRate={currentRate}
        onSelectPtId={handleViewPtDetails}
        onOpenMailBot={() => setActiveTab('mailbot')}
      />

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-500 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">
              Shadowfax NCR Bamnoli DC (Site: NBP)
            </span>
            <span>•</span>
            <span>PT Scan & Payment Management System</span>
          </div>
          <div className="font-mono text-[11px] text-slate-500">
            3-Year Historical Retention • Manual File Ingestion • Machine Sorter Auto-Exclusion • Match Key: Scan_ID
          </div>
        </div>
      </footer>
    </div>
  );
}
