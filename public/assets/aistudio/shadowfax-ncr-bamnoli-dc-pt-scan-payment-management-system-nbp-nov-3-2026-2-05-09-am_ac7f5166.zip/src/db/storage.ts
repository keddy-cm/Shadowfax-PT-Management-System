import {
  AppDatabase,
  PTRosterEntry,
  RateConfig,
  ScanRateRecord,
  ScanHistoryRecord,
  ImportAuditLog,
  UnknownLayoutReview,
  UnregisteredMPReview,
  EmailRecipient,
  EmailDeliveryLog,
  BlockType,
  MailBotConfig,
  DriveConfig,
  DriveSyncLog,
} from '../types';

const STORAGE_KEY = 'SHADOWFAX_NBP_PT_SYSTEM_DB_V2';

export const DEFAULT_DRIVE_FOLDER_ID = '1awbpzVsqjcuNil31zNEuxhC40-vZoodU';
export const DEFAULT_DRIVE_FOLDER_URL = 'https://drive.google.com/drive/folders/1awbpzVsqjcuNil31zNEuxhC40-vZoodU';

export const DEFAULT_DRIVE_CONFIG: DriveConfig = {
  isEnabled: true,
  driveFolderId: DEFAULT_DRIVE_FOLDER_ID,
  driveFolderUrl: DEFAULT_DRIVE_FOLDER_URL,
  autoSyncDaily: true,
  totalSyncedFiles: 0,
};

export const DEFAULT_MAILBOT_CONFIG: MailBotConfig = {
  isEnabled: true,
  scheduleTime: '23:59',
  frequency: 'daily',
  includeExcelAttachment: true,
  includeBlockBreakdown: true,
  includeTopEarners: true,
  customSubject: '[NBP DC Daily Report] PT Scans & Payout Summary',
  lastDispatchedAt: undefined,
  nextScheduledAt: 'Today at 23:59:00 IST',
  totalAutomatedDispatches: 0,
};

// Default blank database schema
export const BLANK_DATABASE: AppDatabase = {
  roster: [],
  rates: [
    {
      id: 'rate-init-2026',
      primary_rate: 0.35,
      secondary_rate: 0.25,
      effective_from: '2026-01-01',
      created_at: new Date().toISOString(),
      created_by: 'Admin',
      note: 'Initial default rate configuration',
    },
  ],
  scanRateRecords: [],
  scanHistoryRecords: [],
  importLogs: [],
  unknownLayouts: [],
  unregisteredMps: [],
  emailRecipients: [
    {
      id: 'rec-0',
      name: 'Kuldeep Chandolia',
      email: 'kuldeep.chandolia@shadowfax.in',
      role: 'Operations Lead / DC Incharge',
      is_active: true,
      created_at: new Date().toISOString(),
    },
    {
      id: 'rec-1',
      name: 'Bamnoli Operations Team',
      email: 'nbp.operations@shadowfax.in',
      role: 'Operations Lead',
      is_active: true,
      created_at: new Date().toISOString(),
    },
    {
      id: 'rec-2',
      name: 'Shift Incharge',
      email: 'nbp.shift@shadowfax.in',
      role: 'DC Shift Incharge',
      is_active: true,
      created_at: new Date().toISOString(),
    },
  ],
  emailLogs: [],
  mailBotConfig: DEFAULT_MAILBOT_CONFIG,
  driveConfig: DEFAULT_DRIVE_CONFIG,
  driveLogs: [],
};

let dbCache: AppDatabase | null = null;

export function loadDatabase(): AppDatabase {
  if (dbCache) return dbCache;

  try {
    const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('SHADOWFAX_NBP_PT_SYSTEM_DB_V1');
    if (!raw) {
      dbCache = JSON.parse(JSON.stringify(BLANK_DATABASE));
      saveDatabase(dbCache!);
      return dbCache!;
    }
    const parsed = JSON.parse(raw);
    
    // Normalize any legacy roster entries to have scan_id and valinor_id
    const normalizedRoster: PTRosterEntry[] = (parsed.roster || []).map((r: any) => ({
      ...r,
      scan_id: r.scan_id || r.mp_id || '',
      valinor_id: r.valinor_id || '',
      mp_id: r.scan_id || r.mp_id || '',
    }));

    // Ensure Manish (user's explicit reference PT: 7088318203 / 16945) exists in roster
    if (!normalizedRoster.some((r) => r.scan_id === '7088318203' || r.mp_id === '7088318203')) {
      normalizedRoster.unshift({
        scan_id: '7088318203',
        valinor_id: 'VAL16945',
        mp_name: 'Manish',
        assigned_block: 'D',
        status: 'Active',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        mp_id: '7088318203',
      });
    }

    // Ensure Kuldeep Chandolia is present in recipients
    const existingRecipients: EmailRecipient[] = parsed.emailRecipients || BLANK_DATABASE.emailRecipients;
    if (!existingRecipients.some((r) => r.email === 'kuldeep.chandolia@shadowfax.in')) {
      existingRecipients.unshift({
        id: 'rec-0',
        name: 'Kuldeep Chandolia',
        email: 'kuldeep.chandolia@shadowfax.in',
        role: 'Operations Lead / DC Incharge',
        is_active: true,
        created_at: new Date().toISOString(),
      });
    }

    // Seed sample scans for Manish if scan records are empty or lack Manish
    let initialScanRateRecords: ScanRateRecord[] = parsed.scanRateRecords || [];
    const todayStr = new Date().toISOString().split('T')[0];
    if (!initialScanRateRecords.some((r) => r.normalized_mp_id === '7088318203')) {
      const sampleHours = [9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
      const manishScans: ScanRateRecord[] = sampleHours.map((h, idx) => {
        const priScans = 120 + ((idx * 17) % 65);
        const secScans = 45 + ((idx * 11) % 35);
        const priEarnings = priScans * 0.35;
        const secEarnings = secScans * 0.25;
        return {
          id: `seed-manish-${h}-${idx}`,
          import_id: 'seed-import',
          operational_date: todayStr,
          action_user: '7088318203@OneNCR_DC',
          normalized_mp_id: '7088318203',
          valinor_id: 'VAL16945',
          layout_name: 'D-Sort-Station-04',
          hour: h,
          scan_count: priScans + secScans,
          process_type: 'PRIMARY',
          is_machine: false,
          is_registered: true,
          assigned_block: 'D',
          primary_rate_applied: 0.35,
          secondary_rate_applied: 0.25,
          primary_earnings: priEarnings,
          secondary_earnings: secEarnings,
          total_earnings: priEarnings + secEarnings,
          created_at: new Date().toISOString(),
        };
      });
      initialScanRateRecords = [...manishScans, ...initialScanRateRecords];
    }

    dbCache = {
      roster: normalizedRoster,
      rates: parsed.rates?.length ? parsed.rates : BLANK_DATABASE.rates,
      scanRateRecords: initialScanRateRecords,
      scanHistoryRecords: parsed.scanHistoryRecords || [],
      importLogs: parsed.importLogs || [],
      unknownLayouts: parsed.unknownLayouts || [],
      unregisteredMps: parsed.unregisteredMps || [],
      emailRecipients: existingRecipients,
      emailLogs: parsed.emailLogs || [],
      mailBotConfig: parsed.mailBotConfig || DEFAULT_MAILBOT_CONFIG,
      driveConfig: (() => {
        const cfg: DriveConfig = parsed.driveConfig || { ...DEFAULT_DRIVE_CONFIG };
        if (
          !cfg.driveFolderUrl ||
          cfg.driveFolderUrl.includes('my-drive') ||
          !cfg.driveFolderId ||
          cfg.driveFolderId === 'Shadowfax_NBP_DC_Reports'
        ) {
          cfg.driveFolderUrl = DEFAULT_DRIVE_FOLDER_URL;
          cfg.driveFolderId = DEFAULT_DRIVE_FOLDER_ID;
        }
        return cfg;
      })(),
      driveLogs: parsed.driveLogs || [],
    };
    return dbCache!;
  } catch (err) {
    console.error('Failed to load database:', err);
    dbCache = JSON.parse(JSON.stringify(BLANK_DATABASE));
    return dbCache!;
  }
}

export function saveDatabase(db: AppDatabase): void {
  try {
    dbCache = db;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch (err) {
    console.error('Failed to persist database to localStorage:', err);
  }
}

export function resetToBlankDatabase(): void {
  const blank = JSON.parse(JSON.stringify(BLANK_DATABASE));
  saveDatabase(blank);
}

// ---------------- Rates Management ----------------
export function getActiveRateForDate(dateStr: string): RateConfig {
  const db = loadDatabase();
  const validRates = db.rates
    .filter((r) => r.effective_from <= dateStr)
    .sort((a, b) => b.effective_from.localeCompare(a.effective_from));

  if (validRates.length > 0) {
    return validRates[0];
  }
  return db.rates[0] || {
    id: 'fallback',
    primary_rate: 0.35,
    secondary_rate: 0.25,
    effective_from: '2026-01-01',
    created_at: new Date().toISOString(),
    created_by: 'System',
  };
}

export function addRateConfig(newRate: Omit<RateConfig, 'id' | 'created_at'>): RateConfig {
  const db = loadDatabase();
  const rate: RateConfig = {
    ...newRate,
    id: 'rate-' + Date.now(),
    created_at: new Date().toISOString(),
  };
  db.rates.push(rate);
  saveDatabase(db);
  return rate;
}

// ---------------- Roster Management ----------------
export function getRoster(): PTRosterEntry[] {
  return loadDatabase().roster;
}

export function saveRosterEntry(entry: PTRosterEntry): void {
  const db = loadDatabase();
  const lookupKey = entry.scan_id || entry.mp_id;
  const existingIdx = db.roster.findIndex(
    (r) => (r.scan_id && r.scan_id === lookupKey) || (r.mp_id && r.mp_id === lookupKey)
  );
  const now = new Date().toISOString();

  const completeEntry: PTRosterEntry = {
    ...entry,
    scan_id: entry.scan_id || entry.mp_id || '',
    mp_id: entry.scan_id || entry.mp_id || '',
    valinor_id: entry.valinor_id || '',
  };

  if (existingIdx >= 0) {
    const existing = db.roster[existingIdx];
    const blockChanged = existing.assigned_block !== completeEntry.assigned_block;
    const history = existing.block_history || [];
    if (blockChanged) {
      history.push({
        block: completeEntry.assigned_block,
        changed_at: now,
      });
    }

    db.roster[existingIdx] = {
      ...existing,
      ...completeEntry,
      updated_at: now,
      block_history: history,
    };
  } else {
    db.roster.push({
      ...completeEntry,
      created_at: now,
      updated_at: now,
      block_history: [
        {
          block: completeEntry.assigned_block,
          changed_at: now,
        },
      ],
    });
  }

  // If this MP was in unregisteredMps, mark it converted
  const unregIdx = db.unregisteredMps.findIndex((u) => u.normalized_mp_id === lookupKey);
  if (unregIdx >= 0) {
    db.unregisteredMps[unregIdx].status = 'CONVERTED_TO_PT';
  }

  saveDatabase(db);
}

export function deactivatePTRoster(scanId: string): void {
  const db = loadDatabase();
  const target = db.roster.find((r) => r.scan_id === scanId || r.mp_id === scanId);
  if (target) {
    target.status = 'Inactive';
    target.updated_at = new Date().toISOString();
    saveDatabase(db);
  }
}

export function replaceRoster(newRoster: PTRosterEntry[]): void {
  const db = loadDatabase();
  db.roster = newRoster.map(r => ({
    ...r,
    scan_id: r.scan_id || r.mp_id || '',
    mp_id: r.scan_id || r.mp_id || '',
    valinor_id: r.valinor_id || '',
  }));
  saveDatabase(db);
}

// ---------------- Scan Rate Records & Hourly Replacement ----------------
export function commitScanRateImport(
  operationalDate: string,
  records: ScanRateRecord[],
  importLog: ImportAuditLog,
  hoursToReplace: Array<string | number>
): void {
  const db = loadDatabase();

  if (hoursToReplace.length > 0) {
    const hourSet = new Set(hoursToReplace.map(String));
    db.scanRateRecords = db.scanRateRecords.filter(
      (r) => !(r.operational_date === operationalDate && hourSet.has(String(r.hour)))
    );
  }

  db.scanRateRecords.push(...records);
  db.importLogs.unshift(importLog);
  saveDatabase(db);
}

// ---------------- Scan History Records ----------------
export function commitScanHistoryImport(
  records: ScanHistoryRecord[],
  importLog: ImportAuditLog
): void {
  const db = loadDatabase();
  db.scanHistoryRecords.push(...records);
  db.importLogs.unshift(importLog);
  saveDatabase(db);
}

// ---------------- Unknown Layouts & Unregistered MPs Tracking ----------------
export function recordUnknownLayout(layoutName: string, dateStr: string, filename: string, scans: number): void {
  const db = loadDatabase();
  const existing = db.unknownLayouts.find((u) => u.layout_name.toUpperCase() === layoutName.toUpperCase());
  if (existing) {
    existing.total_scans_recorded += scans;
  } else {
    db.unknownLayouts.push({
      id: 'ul-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      layout_name: layoutName,
      first_seen_date: dateStr,
      first_seen_file: filename,
      total_scans_recorded: scans,
      status: 'PENDING_REVIEW',
    });
  }
  saveDatabase(db);
}

export function recordUnregisteredMP(rawUser: string, normalizedId: string, dateStr: string, scans: number, layout: string): void {
  const db = loadDatabase();
  const existing = db.unregisteredMps.find((u) => u.normalized_mp_id === normalizedId);
  if (existing) {
    existing.total_scans_recorded += scans;
    existing.last_layout_used = layout;
  } else {
    db.unregisteredMps.push({
      id: 'unreg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      raw_action_user: rawUser,
      normalized_mp_id: normalizedId,
      first_seen_date: dateStr,
      total_scans_recorded: scans,
      last_layout_used: layout,
      status: 'UNREGISTERED',
    });
  }
  saveDatabase(db);
}

// ---------------- Email Scheduler & Delivery Logs ----------------
export function saveEmailRecipient(recipient: EmailRecipient): void {
  const db = loadDatabase();
  const idx = db.emailRecipients.findIndex((r) => r.id === recipient.id);
  if (idx >= 0) {
    db.emailRecipients[idx] = recipient;
  } else {
    db.emailRecipients.push(recipient);
  }
  saveDatabase(db);
}

export function deleteEmailRecipient(id: string): void {
  const db = loadDatabase();
  db.emailRecipients = db.emailRecipients.filter((r) => r.id !== id);
  saveDatabase(db);
}

export function logEmailDelivery(log: EmailDeliveryLog): void {
  const db = loadDatabase();
  db.emailLogs.unshift(log);
  saveDatabase(db);
}

export function updateMailBotConfig(config: Partial<MailBotConfig>): MailBotConfig {
  const db = loadDatabase();
  db.mailBotConfig = {
    ...(db.mailBotConfig || DEFAULT_MAILBOT_CONFIG),
    ...config,
  };
  saveDatabase(db);
  return db.mailBotConfig;
}

export function clearEmailLogs(): void {
  const db = loadDatabase();
  db.emailLogs = [];
  saveDatabase(db);
}

// ---------------- Google Drive Sync & Logs ----------------
export function logDriveSync(log: DriveSyncLog): void {
  const db = loadDatabase();
  if (!db.driveLogs) db.driveLogs = [];
  db.driveLogs.unshift(log);
  if (db.driveConfig) {
    db.driveConfig.totalSyncedFiles = (db.driveConfig.totalSyncedFiles || 0) + 1;
    db.driveConfig.lastSyncedAt = new Date().toISOString();
  }
  saveDatabase(db);
}

export function updateDriveConfig(config: Partial<DriveConfig>): DriveConfig {
  const db = loadDatabase();
  db.driveConfig = {
    ...(db.driveConfig || DEFAULT_DRIVE_CONFIG),
    ...config,
  };
  saveDatabase(db);
  return db.driveConfig;
}

export function clearDriveLogs(): void {
  const db = loadDatabase();
  db.driveLogs = [];
  saveDatabase(db);
}


